Stage 3 reference heading fix (2026-10-26)

1. Copy this ZIP into the Ubuntu project root and unzip it there.
   It adds reports and the patch; existing production files change only in step 2.
2. In the project root:
   patch --dry-run -p1 < stage3_reference_heading_fix.patch
   patch -p1 < stage3_reference_heading_fix.patch
   python -m unittest discover -s tests
3. Add --reference-heading target to run_scene_search.py.
   Omitting this option retains the original ego-heading mode.
4. See docs/stage3_diagnosis/README.md for server commands, results and limits.

The patch changes 3 production modules, updates 2 documentation files,
and adds the regression tests and bounded verification tool.
Candidates remain offline and simulation_verified=false.
