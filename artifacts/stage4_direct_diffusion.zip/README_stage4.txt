Stage4 direct trajectory diffusion / 单 NPC 直接轨迹扩散

Prerequisite: the previous canonical episode split and window-preparation code,
the frozen split/window manifests, NumPy and PyTorch. Optional: Matplotlib.
No trained weights or original dataset files are included.

Run from the Linux project root (skip patch installation if full code was synced):
  unzip -o stage4_direct_diffusion.zip
  patch --dry-run --batch --forward -p1 < stage4_direct_diffusion.patch &&
  patch --batch --forward -p1 < stage4_direct_diffusion.patch
  python -m unittest discover -s tests

Then follow docs/long_tail_stage4.md, in this order:
  1. trajectory_dataset.py --inspect 16 on the existing frozen manifest;
  2. synthetic forward/backward/save/load/sampling smoke;
  3. a small real train/val run and sampling/export;
  4. full train and independent whole-val evaluation.

IMPORTANT: model quality has NOT passed. Local short-training samples have
large displacement errors and motion_valid_rate=0. No full951-episode real
train/val/test, GPU training or SUMO closed-loop execution was run locally.
Candidates are unverified trajectory references, not executable scenarios.
The source history, split, normalizer and original Dreamer code are preserved.

Validation:182 tests passed in43.277 seconds. Actual CPU Torch smoke includes
64 synthetic and40 real single-episode train-only optimization steps, exact
seeded checkpoint round trips, sampling and JSON/NPZ/PNG export. Detailed
evidence: stage4_validation.json (paths there describe the local evidence run).
Torch-dependent tests skip if Torch is absent; check that no such tests skip.
